//
//  PlayViewController.h
//  videoCapture
//
//  Created by 田立彬 on 13-2-25.
//  Copyright (c) 2013年 田立彬. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlayViewController : UIViewController

@property (nonatomic, retain) NSURL* fileURL;

@end
