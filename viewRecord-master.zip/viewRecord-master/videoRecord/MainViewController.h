//
//  MainViewController.h
//  videoRecord
//
//  Created by 田立彬 on 13-3-4.
//  Copyright (c) 2013年 田立彬. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainViewController : UIViewController<UIImagePickerControllerDelegate, UINavigationControllerDelegate>

@end
