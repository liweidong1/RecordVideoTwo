//
//  AppDelegate.h
//  videoRecord
//
//  Created by 田立彬 on 13-2-22.
//  Copyright (c) 2013年 田立彬. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MainViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) MainViewController *viewController;

@end
